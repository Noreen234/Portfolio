# Portfolio Website
GDSC's Fall 23's Second Workshop Project to build your own portifolio.

## Description
Before you start, please install the resources below: <br>
<ul>
  <li>Visual Studio Code: https://code.visualstudio.com/download</li>
  <li>GitHub Extention: Live Server</li>
  <li>Git Bash: https://git-scm.com/downloads</li>
  <li>Assets Folder: https://drive.google.com/drive/folders/1jeJA6KahoaUadTVN9l_A0qHpSVnYVcBZ?usp=sharing</li>
</ul>

GDSC README Template: https://github.com/USFGDSC/ReadMeTemplate

## ScreenShots
<p align="center">
  <img src="https://github.com/USFGDSC/portfolioWebsite/assets/98829238/2ae6df8f-0522-4d74-bec8-f9f0ea1a6a19" width=690px height=900px align="center" />
</p>

## Technologies used:
- HTML, CSS

<p align=center>
Created with ❤️ in DevShops
</p>
